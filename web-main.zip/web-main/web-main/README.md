# do-an
 web bán quần áo

## tải các thư viện 

cd vào project 
cd vào file chính
cd data

vd: D:\web-main\web-main\ex01\data>
npm install cors body-parser mongoose express


## Mô tả dự án

Hệ thống "Quản Lý Sản Phẩm" cho phép admin thêm, sửa, xóa và hiển thị danh sách sản phẩm. Trang web được thiết kế đơn giản, tích hợp Bootstrap 5 và kết nối với API backend.

## Cơ cấu

* **Frontend**:

  * HTML, CSS, JavaScript
  * Thư viện [Bootstrap 5](https://getbootstrap.com/) để thiết kế giao diện.
* **Backend**:

  * API backend được tích hợp với fetch requests.

## Tính năng chính

1. **Quản lý danh sách sản phẩm**

   * Hiển thị danh sách sản phẩm trong bảng.
   * Chức năng tìm kiếm sản phẩm theo tên.

2. **Thêm sản phẩm**

   * Form cho phép admin nhập tên, giá và URL hình ảnh.
   * Sử dụng fetch API gửi request đến backend.

3. **Sửa sản phẩm**

   * Admin nhập tên, giá và hình ảnh mới qua prompt.

4. **Xóa sản phẩm**

   * Xác nhận xóa trước khi gửi request tới backend.

5. **Quản lý giỏ hàng**

   * Tổng quan số lượng sản phẩm trong giỏ.

## Hướng dẫn cài đặt và chạy

1. **Cài đặt backend**:

   * Đảm bảo backend chạy tại `http://localhost:3000`.
   * Backend cung cấp các endpoint như:

     * `GET /products`: Lấy danh sách sản phẩm.
     * `POST /products/add`: Thêm sản phẩm.
     * `PUT /products/update`: Cập nhật thông tin sản phẩm.
     * `DELETE /products/delete/:id`: Xóa sản phẩm.

2. **Cài đặt frontend**:

   * Mở file `admin1.html` trong trình duyệt.
   * Đảm bảo file `scripts.js` kết nối backend chính xác.

3. **Kiểm tra hoạt động**:

   * Tải trang `admin1.html`.
   * Sử dụng form thêm sản phẩm và các chức năng khác như xóa, sửa.

## Các file quan trọng

* `admin1.html`: Giao diện quản lý sản phẩm.
* `server.js`: Chứa các hàm xử lý logic frontend.

## Lưu ý

1. **Quyền admin**:

   * Đảm bảo người dùng có vai trò admin trước khi cho phép quản lý sản phẩm.
   * admin@gmail.com
   mk an2105
   *người dùng:
    có thể tự đăng kí

2. **Kiểm tra backend**:

   * Đảm bảo backend đã được cài đặt và hoạt động.

3. **Trình duyệt**:

   * Hỗ trợ tốt nhất trên các trình duyệt hiện đại như Chrome, Firefox.

